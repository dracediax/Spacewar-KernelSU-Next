#!/system/bin/sh
MODDIR=${0%/*}
RESETPROP="/data/adb/ksu/bin/resetprop"

$RESETPROP partition.system.verified 1
$RESETPROP partition.vendor.verified 1
$RESETPROP partition.product.verified 1
$RESETPROP partition.system_ext.verified 1
$RESETPROP partition.odm.verified 1
