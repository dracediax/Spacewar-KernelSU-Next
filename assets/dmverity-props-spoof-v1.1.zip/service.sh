#!/system/bin/sh
# Runs as a service (later in boot, after ksud is ready)

# Wait for boot to complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

# Try multiple resetprop paths
RP=""
for p in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop resetprop; do
    if [ -f "$p" ] || command -v "$p" >/dev/null 2>&1; then
        RP="$p"
        break
    fi
done

[ -z "$RP" ] && exit 1

$RP partition.system.verified 1
$RP partition.vendor.verified 1
$RP partition.product.verified 1
$RP partition.system_ext.verified 1
$RP partition.odm.verified 1
